<?php
namespace App\yazinc;
use Illuminate\Support\Facades\DB;

 

class hiarch{	
	static $prams;	
	static function has_children($account_list,$id) {
	$resCategory = DB::table(self::$prams['table_name'])->get();
	$account_list = $resCategory->toArray();
	$pid=self::$prams['p_id'];
	foreach ($account_list as $row) {
	if ($row->$pid == $id)
	return true;
	}
	return false;
	}		
	
	
	static function build_menu($rows,$parent=0){
	$resCategory = DB::table(self::$prams['table_name'])->get();
	$account_list = $resCategory->toArray();
	$result = "
	<div class='list-group'>
	<ul class=''>";
	foreach ($account_list as $row)
	{
	$url = url('').self::$prams['url'];
	
	$pid=self::$prams['p_id'];
	$id=self::$prams['id'];
	if ($row->$pid == $parent){
		$title=self::$prams['title'];
	$result.=
	'<li class="">
	<a href="'.$url.$row->$id. 
	'"class="list-group-item list-group-item-action">
	<span">'.$row->$title.'</span>
	</a>
	</li>'
	;
	if (self::has_children($rows,$row->$id))
	$result.= self::build_menu($rows,$row->$id);
	}
	}
	$result.= "</ul></div>";
	return $result;
	}
 
 	static function maping(){
 	return hiarch::build_menu($menu="");
	}
	
}

	
	
	?>