<?php
namespace App\yaz_lib;
use Illuminate\Support\Facades\DB;

 

class cls_menu{
	
	
	static function  account_list(){
	$resCategory = DB::table('accounts')->get();
	$acct_list = $resCategory->toArray();
 	return $acct_list;
	}	
	
	
	static function has_children($account_list,$id) {
	$account_list = cls_menu::account_list();
	foreach ($account_list as $row) {
	if ($row->parent_id == $id)
	return true;
	}
	return false;
	}		
	
	static function build_menu($rows,$parent=0){
	$account_list = cls_menu::account_list(); 	
	$result = "
	<div class='list-group'>
	<ul class=''>";
	foreach ($account_list as $row)
	{
	//Let Show balance against each
	$url = url('').'/profile/';
	if ($row->parent_id == $parent){
	$result.=
	'<li class="">
	<a href="'.$url.$row->account_id. 
	'"class="list-group-item list-group-item-action">
	<span">'.$row->title.'</span>
	</a>
	</li>'
	;
	if (cls_menu::has_children($rows,$row->account_id))
	$result.= cls_menu::build_menu($rows,$row->account_id);
	}
	}
	$result.= "</ul></div>";
	return $result;
	}
 
 	static function maping(){
 	cls_menu::account_list();
 	return cls_menu::build_menu($menu="");
  	
 	
	}
	
}

	
	
	?>